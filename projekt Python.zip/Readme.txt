Zdjęcia pochodzą z https://atlas.roslin.pl/ oraz powszechnie dostępnych źródeł internetowych.

Quiz powinien zadziałać na różnych komputerach i oprogramowaniach, bo pobiera ścieżkę gdzie się znajduje, wystarczy nie zmieniać lokalizacji całości.
Quiz wyświetla zdjęcie rośliny i pozwala użytkownikowi wybrać odpowiedź, liczy czas, zapisuje wynik. 